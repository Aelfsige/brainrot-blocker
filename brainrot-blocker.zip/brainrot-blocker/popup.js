$(document).ready(() => {
    // Variables

    let keyLabel, keyInput, keySelect
    let linkLabel, linkNameInput, linkInput, linkSelect

    keyLabel = $('label[for=key')
    keyInput = $('#keyInput')
    keySelect = $('select[name=key]')

    linkLabel = $('label[for=links]')
    linkNameInput = $('#linkNameInput')
    linkInput = $('#linkInput')
    linkSelect = $('select[name=links]')

    // Variables

    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
        if(tabs[0].url && tabs[0].url.includes('youtube.com/watch')){
            $('.title').text('BrainrotBlocker (v.1.0)')

            // Keywords and Links

            let keywords = ['alpha', 'sigma', 'skibidi', 'fanum', 'gyatt', 'rizz', 'ohio', 'grimace', 'grippy']
            let linkName = ['Markiplier', 'DanTDM']
            let linkLinks = ['https://www.youtube.com/@markiplier', 'https://www.youtube.com/@DanTDM']

            chrome.storage.sync.set({key: keywords, name: linkName, link: linkLinks}, () => {
                console.log('value is set')
            })

            chrome.storage.sync.get(['key', 'name', 'link'], (result) => {
                $.each(result.key, (i) => {
                    keySelect.append($('<option></option>').text(result.key[i]).attr('value', result.key[i]))
                })

                $.each((result.name, result.link), (i) => {
                    linkSelect.append($('<option></option>').text(result.name[i]).attr('value', result.link[i]))
                })
            })

            // Keywords and Links

            // Functions

            $('.save').on('click', () => {
                if(keyInput.val() == ''){
                    alert('Please enter a keyword')
                } else{
                    chrome.storage.sync.get(['key'], (result) => {
                        result.key.push(keyInput.val())
                        $(keySelect).append($('<option></option>').text(keyInput.val()).attr('value', keyInput.val()))
                        console.log(result.key)

                        chrome.storage.sync.set({key: result.key}, () => {
                            console.log('value is added')
                        })
                    })
                }
            })

            $('.delete').on('click', () => {
                const index = keywords.indexOf(keySelect.val())
                
                chrome.storage.sync.get(['key'], (result) => {
                    result.key.splice(index, 1)
                    keySelect.children().get(index).remove()

                    chrome.storage.sync.set({key: result.key}, () => {
                        console.log('value is deleted')
                    })
                })
            })

            $('.linkSave').on('click', () => {
                if(linkNameInput.val() == '' || linkInput.val() == ''){
                    alert('You either have no name for your link or no link at all')
                } else{
                    chrome.storage.sync.get(['name', 'link'], (result) => {
                        result.name.push(linkNameInput.val())
                        result.link.push(linkInput.val())
                        linkSelect.append($('<option></option>').text(linkNameInput.val()).attr('value', linkInput.val()))
                        
                        chrome.storage.sync.set({name: result.name, link: result.link}, () => {
                            console.log('value is added')
                        })
                    })
                }
            })

            $('.linkDelete').on('click', () => {
                const index = linkLinks.indexOf(linkSelect.val())

                chrome.storage.sync.get(['name', 'link'], (result) => {
                    result.name.splice(index, 1)
                    result.link.splice(index, 1)
                    linkSelect.children().get(index).remove()

                    chrome.storage.sync.set({name: result.name, link: result.link}, () => {
                        console.log('value is deleted')
                    })
                })
            })
        } else{
            $('.container').hide()
            $('.title').text('This is not a YouTube Channel')
        }
    })
})