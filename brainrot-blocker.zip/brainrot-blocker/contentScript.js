(() => {
    let currentVideo = ""
    let currentVideoTitle = ""

    chrome.runtime.onMessage.addListener((obj, sender, sendResponse) => {
        const { type, videoId, videoTitle } = obj

        if(type === "NEW"){
            currentVideo = videoId
            currentVideoTitle = videoTitle
            blockVideo()
        }
    })

    const blockVideo = () => {
        let youtubeTitle = document.querySelector('yt-formatted-string.ytd-watch-metadata')
        const splitYoutubeTitle = youtubeTitle.innerHTML.toLowerCase().split(' ')

        chrome.storage.sync.get(['key', 'link'], (result) => {
            for(let i = 0; i < splitYoutubeTitle.length; i++){
                for(let j = 0; j < result.key.length; j++){
                    if(splitYoutubeTitle[i] == result.key[j]){
                        window.location.href = result.link[Math.floor(Math.random() * result.link.length)]
                    }
                }
            }
        })
    }

    blockVideo()
})()